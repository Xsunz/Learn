package cn.itcast.user.domain;

import lombok.Data;

import java.util.Date;


@Data
public class User {

	private Long id;        //主键id
	private String username;//登录名
	private String password;//密码
	private String name;    //真实姓名
	private Integer sex;    //性别
	private Date birthday;
	private String note;
}
