package cn.itcast.user.controller;

import cn.itcast.user.domain.User;
import cn.itcast.user.service.UserService;
import cn.itcast.user.utils.AipFaceHelper;
import com.baidu.aip.util.Base64Util;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;


@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private HttpServletRequest request;

	@Autowired
	private HttpSession session;


	/**
	 * 人脸登录
	 */
	@PostMapping("/faceLogin")
	public String faceLogin(String images) {

		//调用工具类通过图片从百度查找我们自己的用户id
		String id = AipFaceHelper.faceSearch(images);

		//如果id存在，说明识别成功，需要查询数据库获取用户对象保存如session
		if(id != null) {
			User user = userService.findById(Long.parseLong(id));
			session.setAttribute("user",user);
			return "main";//登录成功
		}else{
			request.setAttribute("message","刷脸登录失败");
			return "login";
		}

	}


	/**
	 * 登录
	 */
	@PostMapping("/login")
	public String login(String username,String password) {
		User user = userService.findByUsername(username);
		if(user == null || !user.getPassword().equals(password)){
			request.setAttribute("message","用户或者密码失败");
			return "login";
		}else{
			session.setAttribute("user",user);
			return "main";
		}
	}
}
