package cn.itcast.user.dao;

import cn.itcast.user.domain.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UserDao {

	//根据用户名查询用户
	@Select("select * from tb_user where username=#{username}")
	User findByUsername(String username);

	@Insert("insert into tb_user(id,username,password,name,sex,birthday,note) values(#{id},#{username},#{password},#{name},#{sex},#{birthday},#{note})")
	void save(User user);

	@Select("select * from tb_user where id=#{id}")
	User findById(long l);
}
