package cn.itcast.user.service;

import cn.itcast.user.domain.User;

import java.util.List;

public interface UserService {

	//根据用户名查询用户
	User findByUsername(String username);

	//保存用户
	void save(User user);

	//根据id查询用户
	User findById(long l);
}
