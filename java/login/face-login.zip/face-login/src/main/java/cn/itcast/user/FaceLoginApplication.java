package cn.itcast.user;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication //声明引导类
@MapperScan("cn.itcast.user.dao")
public class FaceLoginApplication {

	//启动方法
	public static void main(String[] args) {
		SpringApplication.run(FaceLoginApplication.class,args);
	}
}
